# Online_Electronics_Maintenance_Management_System
I have created this platform to maintain our household electronics appliances for a long time. I use PHP, Javascript, MySQL, HTML, CSS, Bootstrap, jQuery, ajax and implement an online payment option like Razorpay(for online payments by customers).
