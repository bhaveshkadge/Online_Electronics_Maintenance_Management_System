<!-- Code for Admin Homepage Footer -->
<!DOCTYPE html>
<html>
<head>

	<!-- Link to use Bootstrap contents -->
	<link rel="stylesheet" type="text/css" href="bootstrap/bootstrap.css">
	<!-- Link to use Javascript contents -->
	<script type="text/javascript" src="bootstrap/bootstrap.js"></script>
</head>
<body>

	<div class="container-fluid navbar-dark" style="background-color: steelblue;">
		<div class="row">
			<div class="col-md-12"> <h1 style="font-size: 1.95rem; color: white; font-weight: bold; text-align: center; margin: auto; padding-top: 10px; padding-bottom: 10px;"> Copyright © rahul.kumar@wrmsglobal.com </h1> </div>
			
			<div class="col-md-12" style="text-align: center; color: white; margin: auto;"> <h5>  Contact us on +917011096030, 8750469290</h5> </div> 
		</div>
	</div>
</body>
</html>
