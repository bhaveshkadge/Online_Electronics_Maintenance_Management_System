<!--Code to provide information about "Preventive Maintenance" -->
<!DOCTYPE html>
<html>
<head>
	<title>
		Seemaira's- About Preventive Maintenance 
	</title>

	<!-- Add company icon image in website-->
        <link rel="shortcut icon" href="images/smnew-br.png" type="image/x-icon">

</head>
<body>
		<?php include 'header.php' ?>	<!--including header file, for providing Login/Signup/Logout options-->
		<br>
<div class="container-fluid">
			<div class="row" style="margin-top: 2%;margin-bottom: 2%;">
				
				<div class="col-5" style="margin-left: 3%;">
					<h3 style="margin-left: 12%; margin-top: 6%;"> PREVENTIVE MAINTENANCE </h3>

					<p style="color:Black;text-align: justify;margin-top: 4%;"> <b>We can provide the contract facility to our clients who purchase household products somewhere, and they wants maintenance and management of their products. For such peoples, we can provide them our maintenance management facility through our website "Seemaira's -An Online Electronics Maintenance Management System".</b> <br><br>

					<b> Preventive Maintenance is done in every 3 months and it's is done our side if your product is in warrenty priod then our engineers will comes on your address in every 3 months, and check your products working functinalities or also check it is working properly or not. If your products have any issue in warrenty period then it will fix from us. Maintenance & Management of each and every customer and industry clients should be done here, until clients product's warrenty is avalable, warrenty which is provide by us while client's registration time on our webiste.</b></p>
				
			</div>


			<div class="col-6">
					<div class="col-5">
					<img src="images/preventive 01.jpg" style="width: 262%;height: 399px;margin-top: 15%;margin-left: 20%;">
				</div>
				</div>

		</div>
	</div>
	<br>
	<br>

	<?php include 'footer.php'; ?>		<!--including footer file-->

</body>
</html>