<!-- Code to add "About us" in Homepage-->
<?php require_once "controllerUserData.php";?>	<!-- It is used for unique session for particular user in all web pages-->
	<!DOCTYPE html>
	<html>
	<head>
		<title>
			Seemaira's - About US
		</title>
		<!-- It is used to add Bootstrap contents-->
		<link rel="stylesheet" type="text/css" href="bootstrap/bootstrap.css">
		<!-- It is used to add Javascript contents-->
		<script type="text/javascript" src="bootstrap/bootstrap.js"></script>
		
	</head>
	<body>
		<br> <br>

		<div class="container-fluid">
			<div class="row" style="margin-bottom: 3%;">
				<div class="col-6">
					<div class="col-5">
					<img src="images/about_us.jpg" style="width: 247%; margin-top: 13%; margin-left: 10%;">
				</div>
				</div>

				<div class="col-5">
					<h3 style="margin-left: 42%; margin-top: 6%;"> ABOUT US </h3>

					<p style="color:Black;text-align: justify;margin-top: 4%;"> <b>This "Online Maintenance Management System" helps you in maintaining your electronic products online very easy.</b> <br> <br>

					<b> In this Maintenance Management System we provides our customer to facility of maintenance & management of household things like TV, AC, Refigrator, Washing Machine, Fans, etc. We will provide our clients 1 year of contract in which client's has to submit their some product deails like Manufacture Date of the product, date of purchase, serial number of the product, real price of the product etc. <a href="about_us.php"> read more...</a></b></p>
			</div>

		</div>
	</div>
</body>
</html>