<!-- Code to show information "About Us" -->
<!DOCTYPE html>
<html>
<head>
	<title>About Us </title>

	<!-- Add company icon image in website-->
        <link rel="shortcut icon" href="images/smnew-br.png" type="image/x-icon">

</head>
<body>
	<?php include 'header.php'; ?>	<!-- Include header to show header elements like Login/Logout/Signup -->
	<br>
	<div class="container-fluid">
		<div class="row">
			<div class="col-12">
				<center><h1 style="color: #F31470;"> ABOUT US </h1></center>
			</div>
		</div>


		<div class="row">
			<div class="col-6" style="text-align: justify;">
				<u><h5> About our Maintenance Managemet System   </h5></u>
				<p> In this Maintenance Management System, we provides our facility of maintenance of household things like TV, AC, Refigrator, Washing Machine, Fans, etc. and we adding some more features or services in future to make this website whole rounder, means we will aim to serve all types of electronics appliances best services in future. We will provide our clients 1 year of contract in which client's has to submit their some product details like Manufacture date, Purchase date, Serial number, Real price of the product, etc. </p>

				<u><h6> We can provide two types of facility to our clients:- </h6></u>
				<p> <ol> <li> Preventive Maintenance</li>
					<li> Fault repair</li>
				</ol>
			</p>


			<h4 style="color: #f31470;"> Preventive Maintenance :- </h4>
			<p> In prevcentive Maintenance we can provide 1 year of contract to our clients and in every 3 months we will send our engineers at your home for checking your products condition, like your product working properly or not and does any issues occur on that product or not. If some technical occurs, than our engineer can resolve it.</p>

			<h4 style="color: #f31470;"> Fault Repair :- </h4>
			<p> In fault repair the request is made by client side if client need any help on their product like client's product suddenly stop working, and client can raise request on our Maintenance Management portal they can assist engineer according to their need. Our engineer's will go to client's address and check their product if their is need to change any part than engineer will change it and clients have to pay the amount of those part and we will give 3 months of part replacement warrenty to our clients. </p>
		</div>

		<div class="col-6">
			<img src="images/about us 01.jpg" style="width: inherit; margin-top: 8%;">


		</div>
	</div>
</div>
<br>
<br>

<?php include 'footer.php'; ?>		<!-- To include footer -->

</body>
</html>