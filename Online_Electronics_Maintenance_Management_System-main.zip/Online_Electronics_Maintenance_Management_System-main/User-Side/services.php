<!DOCTYPE html>
<html>
<head>

	<!-- add icon link -->
        <link rel="shortcut icon" href="images/titlelogo.png" type="image/x-icon">
	
	<title> Seemaira's - Services </title>
	<!-- Offline Link -->
	<link rel="stylesheet" type="text/css" href="bootstrap/bootstrap.css">
	<script type="text/javascript" src="bootstrap/bootstrap.js"></script>

	<!-- Online Link CDN Content dilevery network -->
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
</head>
<body>

	<?php include 'header.php' ?>
	<br>

	<div class="container-fluid">
		<h1> What will comes on Preventive Maintenance </h1>
		<p font-size="20px"> We deals with all kind of Household Products and in preventive maintenance we cover a maintenance of product in every quarter which is buy through our customers </p>


		<h1> What comes in Fault Repair </h1>
		<p> Fault repair covers the replacement of parts and it will covers 2 months of warrenty of those parts which is replaced</p>
	</div>
<br>
<br>
	<?php include 'footer.php' ?>
</body>
</html>