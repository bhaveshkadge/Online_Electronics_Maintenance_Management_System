<?php require_once "controllerUserData.php"; ?>
<!DOCTYPE html>
<html>
<head>

	<title>
            Homepage
        </title>
          
        <link rel="shortcut icon" href="images/smnew-br.png" type="image/x-icon">

	<link rel="stylesheet" type="text/css" href="bootstrap/bootstrap.css">

	<script type="text/javascript" src="bootstrap/bootstrap.js"></script>

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

</head>
<body>

	<?php 
	include 'header.php';			
	include 'slider.php';			
	include 'short_about_us.php';	
	include 'footer.php';			
	?>

</body>
</html>