<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Payment Response</title>
	<link rel="shortcut icon" href="images/smnew-br.png" type="image/x-icon">
</head>
<body>
<center>
	<img src="images/Payment-success.png" height="400px">

	<div class="link login-link text-center"><h2 style="color: red;">Note: **Please Go back on Preventive Maintenance Form to submit the contract.</a></h2></div>

</center>
</body>
</html>