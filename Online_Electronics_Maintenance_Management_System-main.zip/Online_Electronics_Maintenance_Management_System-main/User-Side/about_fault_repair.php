<!-- Code for provideing information about "Fault Repair"-->
<!DOCTYPE html>
<html>
<head>
	<title>
		Seemaira's- About Fault Repair
	</title>

	<!-- Add company icon image in website-->
        <link rel="shortcut icon" href="images/smnew-br.png" type="image/x-icon">

</head>
<body>
<?php include 'header.php' ?>	<!--including header file, for providing Login/Signup/Logout options-->
<br>
	<div class="container-fluid">
		<div class="row" style="padding-top: 3%; padding-bottom: 4%;">

			<div class="col-5" style="margin-left: 8%">
				<h3 style="margin-left: 35%; margin-top: 6%;"> FAULT REPAIR </h3>

				<p style="color:Black;text-align: justify;margin-top: 4%;"> <b>This service is provide to you whenever call or request is made by your side, this service cover's your products fault repair and if any need to change products parts if previous part is not working, than it will be changed and we will give you warrenty of that part which is 3 months.</b> <br> <br>

					<b> Doorstep engineer facility if customers/clients products will have any kind of problem. We also provide the warrenty of replaced parts to our clients, which is 3 months of warrenty after replacing it.</b> <br> <br>

					<b> If your product is not working than please fill the given form and submit your product issues as soon as possible. We will try to short out your query as soon as possible by sending our engineer's at your address.</b>
				</p>
				
			</div>


			<div class="col-6">
				<div class="col-5">
					<img src="images/fault repair.jpg" style="width: 193%; margin-top: 13%; margin-left: 20%;">
				</div>
			</div>

		</div>
	</div>
<br>
<br>

	<?php include 'footer.php'; ?>	<!--including footer file-->

</body>
</html>