<?php 
$con = mysqli_connect('localhost', 'root', '', 'maintenance_management');	
?>