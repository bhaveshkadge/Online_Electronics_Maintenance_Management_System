<!-- Code to add footer in web pages like "Copyright © 2019 @Seemaira's.com" -->

<!DOCTYPE html>
<html>
<head>


	<!-- Offline Link for using bootstrap contents-->
	<link rel="stylesheet" type="text/css" href="bootstrap/bootstrap.css">
	<!-- Offline Link for using Javascript contents-->
	<script type="text/javascript" src="bootstrap/bootstrap.js"></script>
</head>
<body>

	<div class="container-fluid navbar-dark" style="background-color: lightseagreen;">
		<div class="row">
			<div class="col-md-12"> <h4 style="font-size: 1.40rem; color: white; font-weight: bold; text-align: center; margin: auto;"> Copyright © 2019 @Seemaira's.com  </h4> </div>
			
			<div class="col-md-12"> <h5 style="text-align: center; font-size: 1.10rem; color: white; margin: auto;"> Contact us on: +917011096030, 8750469290</h5> </div> 
		</div>
	</div>
</body>
</html>